from datetime import date


__version__ = '1.0.2.dev2'
"""The current version of the TurboCtl project."""


copyright = f'2019-{date.today().year} University of Helsinki Fusor Team'
"""Automatically updating copyright information."""
