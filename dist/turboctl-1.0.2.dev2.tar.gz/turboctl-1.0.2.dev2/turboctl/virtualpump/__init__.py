"""This module contains functionality for testing TurboCtl withouit access to
an actual pump.
"""