"""This package is used to form telegrams that send commands to the 
pump.
"""